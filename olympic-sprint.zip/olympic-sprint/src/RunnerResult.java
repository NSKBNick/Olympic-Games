class RunnerResult {
    String name;
    double time;

    public RunnerResult(String name, double time) {
        this.name = name;
        this.time = time;
    }
}