import javax.imageio.ImageIO;
import java.awt.*;
import java.io.IOException;
import java.util.Objects;

public class Runner {
    private int positionX;
    private final int positionY = 175;
    private boolean running = false;
    private Image currentImage;
    private int frameIndex = 0;
    private long lastFrameTime = 0;
    private final int frameDelay = 100; // 100 ms zwischen den Frames
    private double speed = 0.6; // Basis-Geschwindigkeit
    private static final double MAX_SPEED = 5.4; // Maximale Geschwindigkeit
    private static final int FINISH_LINE = 1500; // Ziellinie

    private final Image[] runnerFrames = new Image[8]; // 8 Animations-Frames

    public Runner(int startX) {
        this.positionX = startX - 48;
        loadFrames();
    }

    private void loadFrames() {
        try {
            for (int i = 0; i < 8; i++) {
                runnerFrames[i] = ImageIO.read(Objects.requireNonNull(getClass().getClassLoader()
                        .getResource("runner_" + (i + 1) + ".png")));
            }
            currentImage = runnerFrames[2]; // Startbild setzen (runner_3.png)
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void startRunning() {
        running = true;
    }

    public void move() {
        if (running) {
            if (positionX + speed < FINISH_LINE + 28) { // Läufer bewegt sich nur, bis er komplett die Ziellinie überquert
                positionX += speed;
                updateAnimation();
            } else {
                running = false; // Läufer anhalten
            }
        }
    }

    public void increaseSpeed() {
        if (speed < MAX_SPEED) {
            speed += 0.12; // Geschwindigkeit pro Tastendruck erhöhen
        }
    }

    private void updateAnimation() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastFrameTime >= frameDelay) {
            frameIndex = (frameIndex + 1) % runnerFrames.length; // Nächstes Bild wählen
            currentImage = runnerFrames[frameIndex];
            lastFrameTime = currentTime;
        }
    }

    public void draw(Graphics g) {
        if (currentImage != null) {
            g.drawImage(currentImage, positionX, positionY, 64, 64, null); // Läufer zeichnen
        }
    }

    public int getPositionX() {
        return positionX;
    }
}
