public enum Menu { START, PLACEHOLDER, QUIT }
