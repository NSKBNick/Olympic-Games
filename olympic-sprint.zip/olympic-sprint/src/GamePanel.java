import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Objects;


class GamePanel extends JPanel implements ActionListener, KeyListener {

    //Variablen
    private GameState gameState = GameState.MENU; //Aktueller Zustand
    private Menu selectedOption = Menu.START; // erste Auswahl im Menü
    private final int WIDTH = 1600, HEIGHT = 400; // größe des Fensters
    private final Runner runner; //Läufer
    private final Timer timer; //Timer für updates und repaint → wichtig für animationen
    private Image backgroundImage, runnerImage_1, olympicRings; //Bilder für Menü und Hintergrund
    private Font menuFont, raceFont, readyFont; // Schriftgrößen je nach Situation
    public final int START_LINE = 100; // X Koordinate der Startlinie
    public static final int FINISH_LINE = 1500; // X Koordinate der Ziellinie
    private int countdown = 3; //Countdown für den Start
    private boolean countdownStarted = false;
    private Timer countdownTimer; //Sekundenzähler

    // Zeiterfassung
    private long raceStartTime = 0;
    private long raceTime = 0;
    private boolean raceRunning = false;

    // Ergebnisliste für 8 Läufer (inklusive Spieler)
    private double[] results = new double[8];

    /**
     * Konstruktor der GamePanel.java Klasse
     * Initialisierung des Panels, Aktivierung der Tasteneingabe, Start des Update-Timers, Laden der Ressourcen
     */
    public GamePanel() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setFocusable(true);
        addKeyListener(this);
        runner = new Runner(START_LINE);
        timer = new Timer(1000 / 60, this);
        timer.start();
        loadResources();
        setDoubleBuffered(true);
    }
    //Bilder und Fonts importieren
    private void loadResources() {
        try {
            backgroundImage = ImageIO.read(Objects.requireNonNull(getClass().getClassLoader().getResource("background.jpg")));
            runnerImage_1 = ImageIO.read(Objects.requireNonNull(getClass().getClassLoader().getResource("runner_1.png")));
            olympicRings = ImageIO.read(Objects.requireNonNull(getClass().getClassLoader().getResource("olympic_rings.jpg")));
            InputStream fontStream = getClass().getClassLoader().getResourceAsStream("pixel_font.ttf");

            if (fontStream != null) {
                Font baseFont = Font.createFont(Font.TRUETYPE_FONT, fontStream);
                menuFont = baseFont.deriveFont(25f);
                raceFont = baseFont.deriveFont(20f);
                readyFont = baseFont.deriveFont(32f);
            }
        } catch (IOException | FontFormatException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        switch (gameState) {
            case MENU:
                drawMenu(g);
                break;
            case START_READY:
            case COUNTDOWN:
                drawStartScreen(g);
                break;
            case RACE:
                drawRace(g);
                break;
            case RESULTS:
                drawResults(g); // Ergebnisse nach dem Rennen anzeigen
                break;
        }
    }

    // Design des Menüs
    private void drawMenu(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, WIDTH, HEIGHT);
        g.setColor(Color.BLACK);
        g.setFont(menuFont);
        String[] options = {"100m Sprint", "Weitere Disziplinen", "Spiel verlassen"};
        int yPosition = HEIGHT / 2 + 20;
        for (int i = 0; i < options.length; i++) {
            if (i == selectedOption.ordinal()) {
                g.setColor(Color.RED); // Markierte Option wird rot
            } else {
                g.setColor(Color.BLACK);
            }
            g.drawString(options[i], 1000, yPosition + (i * 60));
        }

        // Zeichnet den Titel
        g.setColor(Color.BLACK);
        g.setFont(g.getFont().deriveFont(Font.PLAIN, 40f));
        g.drawString("Olympische Spiele", 500, 70);

        g.drawImage(runnerImage_1, 700, 160, 200, 200, this);
        g.drawImage(olympicRings, 200, 160, 400, 200, this);
    }

    // Design der Startsequenz
    private void drawStartScreen(Graphics g) {
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, WIDTH, HEIGHT, this);
        }
        g.setColor(Color.WHITE);
        g.fillRect(START_LINE, 20, 5, 360);
        g.fillRect(FINISH_LINE, 20, 5, 360);
        runner.draw(g);

        g.setFont(readyFont);
        if (gameState == GameState.START_READY) {
            drawText(g, "Drücke LEERTASTE, um zu starten", WIDTH / 2 - 500, HEIGHT / 2+20);
        } else if (gameState == GameState.COUNTDOWN) {
            drawText(g, "" + countdown, WIDTH / 2 , HEIGHT / 2 + 20);
        }
    }

    private void drawRace(Graphics g) {
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, WIDTH, HEIGHT, this);
        }
        g.setColor(Color.WHITE);
        g.fillRect(START_LINE, 20, 5, 360);
        g.fillRect(FINISH_LINE, 20, 5, 360);
        runner.draw(g);

        // Zeit während des Rennens anzeigen
        g.setFont(raceFont);
        g.setColor(Color.WHITE);
        g.fillRoundRect(190, 5, 300, 50,10,10);
        g.setColor(Color.BLACK);
        g.drawRoundRect(190,5,300, 50,10,10);
        drawText(g, "Zeit:" + raceTime / 1000.0 + " s", 210, 40);

    }

    // Ergebnisanzeige
    private void drawResults(Graphics g) {
        g.setColor(new Color(0, 0, 0, 150));
        g.fillRect(400, 50, 800, 300);
        g.setColor(Color.WHITE);
        g.setFont(new Font("pixel_font", Font.PLAIN, 24));
        g.drawString("ERGEBNISSE", 700, 80);

        // Ergebnisse nach der Zeit sortiert anzeigen
        for (int i = 0; i < results.length; i++) {
            String name = results[i] == raceTime ? "DU" : "Läufer " + (i + 1);
            double timeInSeconds = results[i] / 1000.0; // Umrechnung von ms zu s
            String formattedTime = String.format("%.3f", timeInSeconds).replace('.', ',');
            g.drawString((i + 1) + ". " + name + " - " + formattedTime + " Sekunden", 450, 120 + (i * 30));
        }

        g.drawString("Drücke ENTER zum verlassen", 850, 330);
    }

    // Methode um verschiedene Texte zu zeichnen
    private void drawText(Graphics g, String text, int x, int y) {
        g.setColor(Color.BLACK);
        g.drawString(text, x, y);
    }
    //3 Sekunden Countdown
    private void startCountdown() {
        countdownStarted = true;
        gameState = GameState.COUNTDOWN;
        countdown = 3;

        countdownTimer = new Timer(1000, e -> {
            if (countdown > 1) {
                countdown--;
            } else {
                countdownTimer.stop();
                gameState = GameState.RACE;
                countdownStarted = false;
                runner.startRunning();
                raceStartTime = System.currentTimeMillis(); // Stoppuhr starten
                raceRunning = true;
            }
            repaint();
        });

        countdownTimer.start();
    }

    // Sortiert Ergebnisse
    private void setResults() {
        // Feste Zeiten der anderen Läufer
        double[] fixedTimes = {9.904, 11.128, 10.578, 10.454, 10.273, 9.783, 12.129};
        double playerTime = raceTime / 1000.0; // Spielerzeit in Sekunden


        RunnerResult[] resultsArray = new RunnerResult[8];

        for (int i = 0; i < 7; i++) {
            resultsArray[i] = new RunnerResult("Läufer " + (i + 1), fixedTimes[i]);
        }

        resultsArray[7] = new RunnerResult("DU", playerTime);

        // Sortiert Ergebnisse nach der Zeit
        Arrays.sort(resultsArray, (r1, r2) -> Double.compare(r1.time, r2.time));

        // Speichert Ergebnisse in Millisekunden
        for (int i = 0; i < resultsArray.length; i++) {
            results[i] = (int) (resultsArray[i].time * 1000); // Ergebnisse in Millisekunden speichern
        }
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (gameState == GameState.RACE) {
            if (raceRunning) {
                raceTime = System.currentTimeMillis() - raceStartTime; // Zeit aktualisieren
            }
            runner.move();
            if (runner.getPositionX() >= FINISH_LINE - 48) {
                raceRunning = false; // Stoppuhr anhalten
                setResults();

                // Verzögerung vor der Anzeige der Ergebnisse
                new Timer(2000, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent evt) {
                        gameState = GameState.RESULTS;
                        repaint();
                    }
                }).start();
            }
        }
        repaint();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (gameState == GameState.MENU) {
            if (e.getKeyCode() == KeyEvent.VK_UP) {
                selectedOption = Menu.values()[(selectedOption.ordinal() + 2) % 3];
            } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                selectedOption = Menu.values()[(selectedOption.ordinal() + 1) % 3];
            } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                if (selectedOption == Menu.START) {
                    gameState = GameState.START_READY;
                } else if (selectedOption == Menu.QUIT) {
                    System.exit(0);
                }
            }
            repaint();
        }
        if (gameState == GameState.RACE) {
            if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                runner.increaseSpeed(); // Geschwindigkeit erhöhen, wenn Leertaste gedrückt wird
            }
        }

        if (gameState == GameState.START_READY && e.getKeyCode() == KeyEvent.VK_SPACE) {
            startCountdown();
        }
        if (gameState == GameState.RESULTS && e.getKeyCode() == KeyEvent.VK_ENTER) {
            System.exit(0);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }
}
