public enum GameState {
    MENU,
    START_READY,
    RACE,
    COUNTDOWN,
    RESULTS
}